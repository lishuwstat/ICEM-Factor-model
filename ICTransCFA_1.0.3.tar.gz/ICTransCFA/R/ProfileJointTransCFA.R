
ProfileJointTransCFA   = function(L, R, CensorIndMat, X, V, LoadingsInitial, r = 0, theta, lamk, ip = 15){
  if (missing(L)){
    stop("Must have a 'L' argument, please see the example showed in the help document and check the input arguments.")
  }
  if (missing(R)){
    stop("Must have a 'R' argument, please see the example showed in the help document and check the input arguments.")
  }
  if (missing(CensorIndMat)){
    stop("Must have a 'CensorIndMat' argument, please see the example showed in the help document and check the input arguments.")
  }
  if (missing(X)){
    stop("Must have a 'X' argument, please see the example showed in the help document and check the input arguments.")
  }
  if (missing(V)){
    stop("Must have a 'V' argument, please see the example showed in the help document and check the input arguments.")
  }
  if (missing(LoadingsInitial)){
    stop("Must have a 'LoadingsInitial' argument, please see the example showed in the help document and check the input arguments.")
  }


  if(any(is.na(LoadingsInitial))){
    stop("There is/are one or more 'NA's exists in the argument 'LoadingsInitial', please see the arguments discription in the help document and check the input arguments.")
  }
  if(any(c(rowSums(LoadingsInitial),colSums(LoadingsInitial))==0)){
    stop("The argument 'LoadingsInitial' should have the correct initial value to enable the function to accurately identify the factor structure, please see the example showed in the help document and check the input arguments.")
  }
  if(any(rowSums(LoadingsInitial)>1)){
    stop("The argument 'LoadingsInitial' should have the correct initial value to enable the function to accurately identify the factor structure, please see the example showed in the help document and check the input arguments.")
  }
  if(any(rowSums(LoadingsInitial)>1)){
    stop("The argument 'LoadingsInitial' should have the correct initial value to enable the function to accurately identify the factor structure, please see the example showed in the help document and check the input arguments.")
  }
  if(dim(LoadingsInitial)[1]!=dim(V)[2]){
    stop("The argument 'LoadingsInitial' should be a 'p*q' matrix and 'p' is the demension if 'V', please see the example showed in the help document and check the input arguments.")
  }
  if(sd(c(length(L), length(R), dim(X)[1], dim(V)[1]))!=0){
    stop("The length of 'L', 'R', 'X' and 'V' is different, please see the arguments discription in the help document and check the input arguments.")
  }
  if(any(is.na(L))){
    stop("There is/are one or more 'NA's exists in the argument 'L', please see the arguments discription in the help document and check the input arguments.")
  }
  if(any(is.na(R))){
    stop("There is/are one or more 'NA's exists in the argument 'R', please see the arguments discription in the help document and check the input arguments.")
  }
  if(any(is.na(X))){
    stop("There is/are one or more 'NA's exists in the argument 'X', please see the arguments discription in the help document and check the input arguments.")
  }
  if(any(is.na(CensorIndMat))){
    stop("There is/are one or more 'NA's exists in the argument 'Z', please see the arguments discription in the help document and check the input arguments.")
  }
  if(any(is.na(V))){
    stop("There is/are one or more 'NA's exists in the argument 'V', please see the arguments discription in the help document and check the input arguments.")
  }

  if(!(is.matrix(X))){
    X=as.matrix(X)
  }

  n=length(L)

  d1 = CensorIndMat[,1]
  d2 = CensorIndMat[,2]
  d3 = CensorIndMat[,3]

  s  = dim(X)[2]
  p  = dim(LoadingsInitial)[1]
  q  = dim(LoadingsInitial)[2]

  p.sub = colSums(LoadingsInitial)
  obs.data = cbind(L, R, CensorIndMat, X, V)
  Censor_rate = colMeans(CensorIndMat)
  if(any(L==0)){order.LR = unique(sort(c(L,R)))[-1]}
  if(any(R==9999)){order.LR = order.LR[-length(order.LR)]}

  Kn       = length(order.LR)

  Ind.L    = (matrix(rep(order.LR,each = n),n,Kn) <= matrix(rep(L,Kn),n,Kn))*1
  Ind.R    = (matrix(rep(order.LR,each = n),n,Kn) <= matrix(rep(R,Kn),n,Kn))*1
  Ind.LR   = Ind.R-Ind.L


  f.hat = f.ini = lamk
  b.hat = theta[1:s]
  gam.hat = theta[(s+1):(s+q)]
  B.hat   = LoadingsInitial
  B.hat[B.hat!=0] = theta[(s+q+1):(s+q+p)]
  B1.hat=theta[(s+q+1):(s+q+p)]
  psi.hat = diag(theta[(s+q+p+1):(s+q+p+p)])
  phi.hat = diag(rep(1,q))
  phi.hat[upper.tri(phi.hat)] = phi.hat[lower.tri(phi.hat)] = theta[(s+q+p+p+1):(length(theta))]
  loops=0
  diff.theta = 100
  tol=0.001
  max.loops = 30000
  while(diff.theta >= tol && loops < max.loops){
    grid = myinitquad(Q = q, Sigma = phi.hat, ip = ip)
    W.xi = grid$W
    X.xi = grid$X
    if(r>0){Evalues = Efunprofile(X.xi, W.xi, gam.hat, X, b.hat, f.hat, psi.hat, d3, Ind.L, Ind.R, V, B.hat, r, pi)
    }else{Evalues = EfunCoxprofile(X.xi, W.xi, gam.hat, X, b.hat, f.hat, psi.hat, d3, Ind.L, Ind.R, V, B.hat, pi)}
    sumf = Evalues[[1]]
    up1  = Evalues[[2]]
    up2  = Evalues[[3]]

    E_xi.egx.mu = as.vector(up1/sumf)
    E_xi.Z1  = as.vector(up2/sumf)
    E.Z  = exp(X%*%b.hat)%*%t(f.hat)*(E_xi.Z1*(1-d3)*Ind.LR + E_xi.egx.mu*((1-d3)*(1-Ind.R)+d3*(1-Ind.L)))

    f.est = apply(E.Z,2,sum)/sum(exp(X%*%b.hat)*E_xi.egx.mu)

    if(any(is.na(f.est))) f.est = f.ini
    diff.f = abs(f.est-f.hat)
    diff.theta = sum(diff.f)
    f.hat = f.est
    loops = loops+1
  }

  if(r>0){Evalues = Efun(X.xi, W.xi, gam.hat, X, b.hat, f.hat, psi.hat, d3, Ind.L, Ind.R, V, B.hat, r, pi)
  }else{Evalues = EfunCox(X.xi, W.xi, gam.hat, X, b.hat, f.hat, psi.hat, d3, Ind.L, Ind.R, V, B.hat, pi)}
  sumf = Evalues[[1]]
  up1  = Evalues[[2]]
  up2  = Evalues[[3]]
  up3  = Evalues[[4]]
  up4  = Evalues[[5]]
  up6  = Evalues[[7]]
  up5  = up7 = array(0,dim=c(n,q,q))
  for(ii in 1:n){up5[ii,,] = (Evalues[[6]])[(q*(ii-1)+1):(q*ii),]; up7[ii,,] = (Evalues[[8]])[(q*(ii-1)+1):(q*ii),]}

  E_xi.egx.mu = as.vector(up1/sumf)
  E_xi.Z1  = as.vector(up2/sumf)
  E_xi.Z1[is.na(E_xi.Z1)] = 0
  lebz = exp(X%*%b.hat)%*%t(f.hat)
  EZ1  = lebz*E_xi.Z1*(1-d3)*Ind.LR

  EZ23 = lebz*E_xi.egx.mu*((1-d3)*(1-Ind.R)+d3*(1-Ind.L))
  E.Z  = EZ1 + EZ23
  E_xi.Zxi.1 = up3/sumf
  E_xi.Zxi.1[is.na(E_xi.Zxi.1)] = 0
  E_xi.egx.x.mu = up4/sumf

  EZxi1 = EZxi23 = E.Zxi = array(0,dim = c(n,Kn,q))
  for (ii in 1:q) {
    EZxi1[,,ii]  = lebz*E_xi.Zxi.1[,ii]*(1-d3)*Ind.LR
    EZxi23[,,ii] = lebz*E_xi.egx.x.mu[,ii]*((1-d3)*(1-Ind.R)+d3*(1-Ind.L))
    E.Zxi[,,ii]  = EZxi1[,,ii] + EZxi23[,,ii]
  }

  E_xi.egx.xx.mu = up5/sumf
  E_xi.x = up6/sumf

  E_xi.xx = up7/sumf

  E_xi.xi2 = cbind(E_xi.xx[,1,1],E_xi.xx[,2,2])


  U.beta = t(X)%*%rowSums(E.Z-lebz*E_xi.egx.mu)

  U.gam=rep(0,q)
  for(ii in 1:q){U.gam[ii]=sum(E.Zxi[,,ii] - lebz * E_xi.egx.x.mu[,ii])}


  hhhh = xxxx = c()
  for(ii in 1:q){
    hhhh=c(hhhh, colSums(V[,which(LoadingsInitial[,ii]!=0)]*E_xi.x[,ii]))
    xxxx=c(xxxx, rep(sum(E_xi.xi2[,ii]), each=p.sub[ii]))
  }
  U.B1    = (hhhh-B.hat[B.hat!=0]*xxxx)/diag(psi.hat)

  sub=c()
  for(ii in 1:q){ sub = c(sub, rep(ii, p.sub[ii])) }
  U.psi = -0.5*n/diag(psi.hat)+0.5*colSums(V^2+t(B1.hat^2*t(E_xi.xi2[,sub]))- 2*t(B1.hat*t(E_xi.x[,sub]))*V)/diag(psi.hat)^2

  phi.est=phi.hat
  invphi = solve(phi.hat)
  temp_mat = apply(E_xi.xx,3,colSums)
  U.phi = phi.hat
  if(q>1){
    for(ii in 2:q){
      for(jj in 1:(ii-1)){
        dphi1 = dphi2 = matrix(0,q,q)
        dphi1[ii, jj]=dphi2[ii, jj]=dphi1[jj, ii]=dphi2[jj, ii]=1
        U.phi[ii,jj] = U.phi[jj, ii] = 0.5*as.numeric(tr(invphi%*%(temp_mat - n*phi.hat)%*%invphi%*%dphi1))
      }
    }
  }

  U=c(U.beta, U.gam, U.B1, U.psi, U.phi[lower.tri(U.phi)])
  return(U)
}
