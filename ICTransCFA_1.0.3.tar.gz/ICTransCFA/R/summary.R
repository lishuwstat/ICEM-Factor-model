
summary.JointTransCFA <- function(object, ...){
  if(!inherits(object,"JointTransCFA"))
    stop("Object must be of class 'JointTransCFA' !")
  cat("Left-, Interval- and Right-censoring rate: \n")
  ICstatTab=data.frame(object$Censor.num, object$Censor.rate)
  rownames(ICstatTab) = c("Left-", "Interval-", "Right-")
  colnames(ICstatTab) = c("Count", "Rate")
  ICstatTab$Rate=sprintf("%1.2f%%", 100*ICstatTab$Rate)
  print(ICstatTab)
  cat("\n\n")

  s=length(object$beta.hat)
  p=dim(object$Loadings.hat)[1]
  q=dim(object$Loadings.hat)[2]
  p.sub=colSums(object$Loadings.hat)

  Est = object$theta.hat
  Std = object$see.b
  zvalue =  Est/Std
  pvalue <- object$p.values
  zvalue[is.na(pvalue)]=NA

  CoeTab = data.frame(cbind(Est,Std,zvalue,pvalue))
  CoeTab$stars=""
  CoeTab$stars[CoeTab$pvalue <   .1] <- "."
  CoeTab$stars[CoeTab$pvalue <  .05] <- "*"
  CoeTab$stars[CoeTab$pvalue <  .01] <- "**"
  CoeTab$stars[CoeTab$pvalue < .001] <- "***"
  CoeTab=CoeTab[1:(s+q+p),]

  colnames(CoeTab)=c("Estimate","Std.Error","z value","Pr(>|z|)","")

  Bmatname=c()
  for(i in 1:q){
    Bmatname=c(Bmatname,paste0("B",which(object$Loadings.hat[,i]!=0),rep(i,p.sub[i])))
  }
  rownames(CoeTab)=c(paste0("X",1:length(object$beta.hat)), paste0("eta",1:length(object$gamma.hat)), Bmatname)
  cat("Coefficients: \n")
  print(CoeTab, digits = 3, zero.print = "")
  cat("---\nSignif. codes: 0 '***' 0.001 '**' 0.01 '*' 0.05 '.' 0.1 ' ' 1\n\n\n")

  cat("Psi and Std estimates: \n")
  print(object$Psi.hat, digits = 3, zero.print = "")
  print(diag(Std[(s+q+p+1):(s+q+p+p)]), digits = 3, zero.print = "")
  cat(" \n\n\n")

  cat("Phi and Std estimates: \n")
  print(object$Phi.hat, digits = 3, zero.print = "")
  std.phi=diag(rep(0,q))
  std.phi[lower.tri(std.phi)]=std.phi[upper.tri(std.phi)]=Std[(s+q+p+p+1):(s+q+p+p+q*(q-1)/2)]
  print(std.phi, digits = 3, zero.print = "")

}
