
simulataJointTransCFA = function(n = 200, r = 0, beta = matrix(0.5), gam = matrix(c(0.5, -0.5)), Loadings = array(c(rep(0.8,3),rep(0,6),rep(0.8,3)), dim = c(6,2)),
                               Psi = diag(rep(0.3, 6)), Phi = array(c(1,0.2,0.2,1), dim = c(2,2)), Lam ="linear"){
  s=length(beta)
  p=dim(Loadings)[1]
  q=dim(Loadings)[2]
  X   = matrix(rbinom(n*s,1,0.5), ncol = s)
  xi  = rmvnorm(n,mean = rep(0,q), sigma = Phi)
  V   = xi%*%t(Loadings) + rmvnorm(n, mean = rep(0,p), sigma = Psi)
  v   = runif(n)
  if(Lam=="linear"){
    Ti  = Ginv(-log(v),r)*exp(-X%*%beta-xi%*%gam)*2
  }
  if(Lam=="logarithm"){
    Ti  = exp(Ginv(-log(v),r)*exp(-X%*%beta-xi%*%gam))-1
  }
  Cn       = cbind(0,t(apply(matrix(0.1+runif(20*n),n,20), 1, cumsum)))
  Cn[Cn>3] = NA
  Ind      = rowSums(as.vector(Ti)>=Cn, na.rm=TRUE)
  Li=Ri=c()
  for(i in 1:n){Li[i] = Cn[i,Ind[i]];Ri[i]=Cn[i,Ind[i]+1]}
  Ri[is.na(Ri)] = 9999
  Delta = matrix(0,n,3)
  Delta[,1] = Li==0
  Delta[,3] = Ri==9999
  Delta[,2] = 1-Delta[,1]-Delta[,3]
  return(list(L = Li, R = Ri, X = X, CensorIndMat = Delta, V = V, LoadingsInitial = Loadings, r=r))
}
