
plot.JointTransCFA<- function(x, type="hazard", ...){
  if(!inherits(x,"JointTransCFA"))
    stop("Object must be of class 'JointTransCFA' !")

  if(missing(type)|type=="hazard"){
    plot(x$order.LR,cumsum(x$lamk.hat),type="s",ylab="",
         xlab="time", main="Cummulative baseline hazard")
  }

  if(type=="survival"){
    plot(x$order.LR,exp(-cumsum(x$lamk.hat)),type="s",ylab="",
         xlab="time", main="Baseline Survival")
  }
}
