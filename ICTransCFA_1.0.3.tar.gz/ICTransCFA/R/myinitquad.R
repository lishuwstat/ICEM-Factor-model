myinitquad = function (Q, Sigma, ip) {
  x <- gaussHermiteData(ip)
  w <- x$w/sqrt(pi)
  x <- x$x*sqrt(2)
  X <- as.matrix(expand.grid(lapply(apply(replicate(Q, x), 2, list), unlist)))
  W <- apply(as.matrix(expand.grid(lapply(apply(replicate(Q, w), 2, list), unlist))), 1, function(x) sum(log(x)))
  X <- t(eigen(Sigma)$vectors %*% diag(sqrt(eigen(Sigma)$values)) %*% t(X))
  return(invisible(list(X = X, W = W)))
}
