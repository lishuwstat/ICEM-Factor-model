
tr = function(A) {
  sum(diag(A))
}
