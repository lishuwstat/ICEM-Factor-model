Ginv  = function(u, r){
  if (r > 0) {
    results = (exp(u*r)-1)/r
  } else results = u
  return(results)
}
