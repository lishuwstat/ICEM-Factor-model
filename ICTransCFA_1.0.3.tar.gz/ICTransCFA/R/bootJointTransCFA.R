
bootJointTransCFA = function(L, R, CensorIndMat, X, V, LoadingsInitial, r = 0, B = 100, ip = 15, seed = 999){
  if (missing(L)){
    stop("Must have a 'L' argument, please see the example showed in the help document and check the input arguments.")
  }
  if (missing(R)){
    stop("Must have a 'R' argument, please see the example showed in the help document and check the input arguments.")
  }
  if (missing(CensorIndMat)){
    stop("Must have a 'CensorIndMat' argument, please see the example showed in the help document and check the input arguments.")
  }
  if (missing(X)){
    stop("Must have a 'X' argument, please see the example showed in the help document and check the input arguments.")
  }
  if (missing(V)){
    stop("Must have a 'V' argument, please see the example showed in the help document and check the input arguments.")
  }
  if (missing(LoadingsInitial)){
    stop("Must have a 'LoadingsInitial' argument, please see the example showed in the help document and check the input arguments.")
  }


  if(any(is.na(LoadingsInitial))){
    stop("There is/are one or more 'NA's exists in the argument 'LoadingsInitial', please see the arguments discription in the help document and check the input arguments.")
  }
  if(any(c(rowSums(LoadingsInitial),colSums(LoadingsInitial))==0)){
    stop("The argument 'LoadingsInitial' should have the correct initial value to enable the function to accurately identify the factor structure, please see the example showed in the help document and check the input arguments.")
  }
  if(any(rowSums(LoadingsInitial)>1)){
    stop("The argument 'LoadingsInitial' should have the correct initial value to enable the function to accurately identify the factor structure, please see the example showed in the help document and check the input arguments.")
  }
  if(any(rowSums(LoadingsInitial)>1)){
    stop("The argument 'LoadingsInitial' should have the correct initial value to enable the function to accurately identify the factor structure, please see the example showed in the help document and check the input arguments.")
  }
  if(dim(LoadingsInitial)[1]!=dim(V)[2]){
    stop("The argument 'LoadingsInitial' should be a 'p*q' matrix and 'p' is the demension if 'V', please see the example showed in the help document and check the input arguments.")
  }
  if(sd(c(length(L), length(R), dim(X)[1], dim(V)[1]))!=0){
    stop("The length of 'L', 'R', 'X' and 'V' is different, please see the arguments discription in the help document and check the input arguments.")
  }
  if(any(is.na(L))){
    stop("There is/are one or more 'NA's exists in the argument 'L', please see the arguments discription in the help document and check the input arguments.")
  }
  if(any(is.na(R))){
    stop("There is/are one or more 'NA's exists in the argument 'R', please see the arguments discription in the help document and check the input arguments.")
  }
  if(any(is.na(X))){
    stop("There is/are one or more 'NA's exists in the argument 'X', please see the arguments discription in the help document and check the input arguments.")
  }
  if(any(is.na(CensorIndMat))){
    stop("There is/are one or more 'NA's exists in the argument 'CensorIndMat', please see the arguments discription in the help document and check the input arguments.")
  }
  if(any(is.na(V))){
    stop("There is/are one or more 'NA's exists in the argument 'V', please see the arguments discription in the help document and check the input arguments.")
  }



  n=length(L)

  d1 = CensorIndMat[,1]
  d2 = CensorIndMat[,2]
  d3 = CensorIndMat[,3]

  s  = dim(X)[2]
  p  = dim(LoadingsInitial)[1]
  q  = dim(LoadingsInitial)[2]

  p.sub = colSums(LoadingsInitial)
  obs.data = cbind(L, R, CensorIndMat, X, V)
  theta.boot=c()
  for(irep in 1:B){
    irep=1
    set.seed(seed+irep)
    sub = sample(1:n, n, replace = TRUE)
    data_out1=obs.data[sub,]
    L=data_out1[,1]
    R=data_out1[,2]
    d1 = data_out1[,3]
    d2 = data_out1[,4]
    d3 = data_out1[,5]
    X  = as.matrix(data_out1[,6:(5+s)])
    V  = data_out1[,(5+s+1):(5+s+p)]

    if(any(L==0)){order.LR = unique(sort(c(L,R)))[-1]}
    if(any(R==9999)){order.LR = order.LR[-length(order.LR)]}

    Kn       = length(order.LR)

    Ind.L    = (matrix(rep(order.LR,each = n),n,Kn) <= matrix(rep(L,Kn),n,Kn))*1
    Ind.R    = (matrix(rep(order.LR,each = n),n,Kn) <= matrix(rep(R,Kn),n,Kn))*1
    Ind.LR   = Ind.R-Ind.L

    b.hat    = b.ini = matrix(rep(0,s))
    gam.hat  = gam.ini = rep(0,q)
    lamk.hat = lamk.ini = rep(1/Kn,Kn)

    phi.hat  = phi.ini = diag(rep(1,q))
    psi.hat  = psi.ini = diag(rep(1,p))
    B.hat    = B.ini   = LoadingsInitial

    loops    = 0
    diff.theta = 100
    tol=0.001
    max.loops = 5000
    while(diff.theta >= tol && loops < max.loops){

      grid = myinitquad(Q = q, Sigma = phi.hat, ip = ip)
      W.xi = grid$W
      X.xi = grid$X
      if(r>0){Evalues = Efun(X.xi, W.xi, gam.hat, X, b.hat, lamk.hat, psi.hat, d3, Ind.L, Ind.R, V, B.hat, r, pi)
      }else{Evalues = EfunCox(X.xi, W.xi, gam.hat, X, b.hat, lamk.hat, psi.hat, d3, Ind.L, Ind.R, V, B.hat, pi)}

      sumf = Evalues[[1]]
      up1  = Evalues[[2]]
      up2  = Evalues[[3]]
      up3  = Evalues[[4]]
      up4  = Evalues[[5]]
      up6  = Evalues[[7]]
      up5  = up7 = array(0,dim=c(n,q,q))
      for(ii in 1:n){up5[ii,,] = (Evalues[[6]])[(q*(ii-1)+1):(q*ii),]; up7[ii,,] = (Evalues[[8]])[(q*(ii-1)+1):(q*ii),]}

      E_xi.egx.mu = as.vector(up1/sumf)
      E_xi.Z1  = as.vector(up2/sumf)
      E_xi.Z1[is.na(E_xi.Z1)] = 0
      lebz = exp(X%*%b.hat)%*%t(lamk.hat)
      EZ1  = lebz*E_xi.Z1*(1-d3)*Ind.LR

      EZ23 = lebz*E_xi.egx.mu*((1-d3)*(1-Ind.R)+d3*(1-Ind.L))
      E.Z  = EZ1 + EZ23
      E_xi.Zxi.1 = up3/sumf
      E_xi.Zxi.1[is.na(E_xi.Zxi.1)] = 0
      E_xi.egx.x.mu = up4/sumf

      EZxi1 = EZxi23 = E.Zxi = array(0,dim = c(n,Kn,q))
      for (ii in 1:q) {
        EZxi1[,,ii]  = lebz*E_xi.Zxi.1[,ii]*(1-d3)*Ind.LR
        EZxi23[,,ii] = lebz*E_xi.egx.x.mu[,ii]*((1-d3)*(1-Ind.R)+d3*(1-Ind.L))
        E.Zxi[,,ii]  = EZxi1[,,ii] + EZxi23[,,ii]
      }

      E_xi.egx.xx.mu = up5/sumf

      E_xi.x = up6/sumf


      E_xi.xx  = up7/sumf
      E_xi.xi2 = c()
      for (ii in 1:q) { E_xi.xi2 = cbind(E_xi.xi2, E_xi.xx[,ii,ii]) }



      lamk.est = apply(E.Z,2,sum)/sum(exp(X%*%b.hat)*E_xi.egx.mu)
      lebz = exp(X%*%b.hat)%*%t(lamk.est)

      U.beta = t(X)%*%rowSums(E.Z-lebz*E_xi.egx.mu)
      I.beta = -t(X^2)%*%rowSums(lebz*E_xi.egx.mu)
      b.est  = b.hat-U.beta/I.beta

      U.gam = rep(0,q)
      for(ii in 1:q){U.gam[ii]=sum(E.Zxi[,,ii] - lebz * E_xi.egx.x.mu[,ii])}
      I.gam=apply(-rowSums(lebz) * E_xi.egx.xx.mu,3,colSums)
      gam.est  = gam.hat-solve(I.gam)%*%U.gam



      U.B1 = I.B1 = c()
      for(ii in 1:q){
        U.B1=c(U.B1, colSums(V[,which(LoadingsInitial[,ii]!=0)]*E_xi.x[,ii]))
        I.B1=c(I.B1, rep(sum(E_xi.xi2[,ii]), each=p.sub[ii]))
      }
      B1.est  = U.B1/I.B1
      B.mat=B1.est[1:p.sub[1]]
      if(q>1){ for(ii in 1:(q-1)){ B.mat = c(B.mat, rep(0,p), B1.est[(p.sub[ii]+1):(p.sub[ii]+p.sub[ii+1])]) } }
      B.est = matrix(B.mat, ncol = q)

      sub=c()
      for(ii in 1:q){ sub = c(sub, rep(ii, p.sub[ii])) }
      psi.diag.est = colMeans(V^2+t(B1.est^2*t(E_xi.xi2[,sub]))- 2*t(B1.est*t(E_xi.x[,sub]))*V)
      psi.est = diag(psi.diag.est)

      phi.est=phi.hat
      invphi = solve(phi.hat)
      temp_mat = apply(E_xi.xx,3,colSums)
      if(q>1){
        for(ii in 2:q){
          for(jj in 1:(ii-1)){
            dphi1 = dphi2 = matrix(0,q,q)
            dphi1[ii, jj]=dphi2[ii, jj]=dphi1[jj, ii]=dphi2[jj, ii]=1
            U.phi    = 0.5*as.numeric(tr(invphi%*%(temp_mat - n*phi.hat)%*%invphi%*%dphi1))
            I.phi    = -0.5*as.numeric(tr(invphi%*%dphi1%*%invphi%*%(2*temp_mat - n*phi.hat)%*%invphi%*%dphi2))
            phi.est[ii,jj]    = phi.est[jj,ii] = phi.est[jj,ii] - as.numeric(solve(I.phi))*U.phi
            if(phi.est[ii,jj]>=1) phi.est[ii,jj]=phi.ini[ii,jj]
          }
        }
      }


      diff.theta   = sum(abs(c(lamk.est-lamk.hat, b.est-b.hat, gam.est-gam.hat, as.vector(B.est-B.hat), diag(psi.est-psi.hat), as.vector(phi.est-phi.hat))))

      lamk.hat  = lamk.est
      b.hat     = b.est
      gam.hat   = gam.est
      B.hat     = B.est
      psi.hat   = psi.est
      phi.hat   = phi.est

      loops     = loops + 1
    }
    theta.hat = c(b.hat, gam.hat, B.hat[B.hat!=0], diag(psi.hat), phi.hat[lower.tri(phi.hat)])
    theta.boot = cbind(theta.boot, theta.hat)
  }
  return(apply(theta.boot, 1, sd))

}

