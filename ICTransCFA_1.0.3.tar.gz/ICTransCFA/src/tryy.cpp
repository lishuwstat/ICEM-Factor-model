#include <Rcpp.h>
#include <RcppEigen.h>
#include <iostream>

// [[Rcpp::depends(RcppEigen)]]
using namespace Rcpp;
using namespace std;

using Eigen::Map;
using Eigen::MatrixXd;
using Eigen::VectorXd;
using Eigen::ArrayXd;
using Eigen::ArrayXXd;

//[[Rcpp::export]]
Eigen::VectorXd Gfun(Eigen::VectorXd u, double r){
  const int n(u.size());
  Eigen::VectorXd results(n), hh(n);
  if(r > 0){
    hh=1+r*(u.array()); results.fill(0);
    results = (hh.array()<=results.array()).cast<double>();
    results = log(results.array()*0.001+(1-results.array())*hh.array())/r;
  }
  else{
    results = u;
  }
  return results;
}

//[[Rcpp::export]]
Eigen::VectorXd dGfun(Eigen::VectorXd u, double r){
  const int n(u.size());
  Eigen::VectorXd results(n);
  if(r > 0){
    results = 1/(1+r*(u.array()));
  }
  else{
    results.fill(1);
  }
  return results;
}


//[[Rcpp::export]]
List Efun(Eigen::MatrixXd XX,   Eigen::VectorXd WW,   Eigen::VectorXd gam,  Eigen::MatrixXd X,
             Eigen::VectorXd b,    Eigen::VectorXd h,    Eigen::MatrixXd Psi,  Eigen::VectorXd d3,
             Eigen::MatrixXd IndL, Eigen::MatrixXd IndR, Eigen::MatrixXd V,    Eigen::MatrixXd B,
             double r, double pi){
  const int ipq(XX.rows()), n(d3.size()), q(XX.cols()), p(V.cols()), k(h.size());
  Eigen::MatrixXd newxi(n,q), h3(n,q), h4(n,q), up3(n,q), up4(n,q), lebzegx(n,k);
  Eigen::MatrixXd up6(n,q), up5(n*q,q), up7(n*q,q), fh5(n*q,q), xx(q,q);
  Eigen::VectorXd inpsi(p), Vi(n), Wi(n), Emu(n), egx(n), ebzgx(n), egxmu(n);
  Eigen::VectorXd f(n), FF(n), h1(n), fh1(n), fh2(n), h2(n), up1(n), up2(n);
  Eigen::ArrayXd  logcfa(n), logl(n), sL(n), sR(n), diffS(n), logsd3(n), Emufrac(n), dGVi(n), dGWi(n);
  double C0;

  FF.fill(0); up1.fill(0); up2.fill(0); up3.fill(0); up4.fill(0); up5.fill(0); up6.fill(0); up7.fill(0);

  for(int i = 0; i < p; ++i){inpsi(i) = 1/Psi(i,i);}
  C0 = p*log(2*pi)+log(Psi.determinant());


  for (int ii = 0; ii < ipq; ++ii){
    newxi = XX.row(ii).replicate(n,1);

    egx    = (newxi * gam).array().exp();
    ebzgx  = (X * b + newxi * gam).array().exp();
    logcfa = (((V.array()-(newxi*B.adjoint()).array()).square()).matrix()*inpsi).array()+C0;

    lebzegx = ebzgx*h.transpose();
    Vi = (lebzegx.cwiseProduct(IndL)).rowwise().sum();
    Wi = (lebzegx.cwiseProduct(IndR)).rowwise().sum();
    sL = (-Gfun(Vi,r)).array().exp();
    sR = (-Gfun(Wi,r)).array().exp();


    diffS  = sL-sR;
    logsd3 = sL.log();

    dGVi = dGfun(Vi, r);
    dGWi = dGfun(Wi, r);
    for(int i = 0; i < n; ++i){
      if(diffS(i) == 0){diffS(i) = 0.00001;}
      if(logsd3(i) == log(0.0)){logsd3(i) = -100000;}
      if(d3(i) != 1){
        logl(i) = log(diffS(i)) - 0.5*logcfa(i);
        Emu(i)  = (sL(i)*dGVi(i) - sR(i)*dGWi(i))/diffS(i);
      }
      else{
        logl(i) = logsd3(i) - 0.5*logcfa(i);
        Emu(i)  = dGVi(i);
      }
    }

    Emufrac = sL.cwiseProduct(dGVi);

    egxmu   = egx.cwiseProduct(Emu);

    f  = exp(logl+WW(ii));
    FF += f;

    fh1 = f.cwiseProduct(egxmu);
    up1 += fh1;


    fh2 = egx.array()/diffS*Emufrac*f.array();
    up2 += fh2;


    up3 += newxi.cwiseProduct(fh2.replicate(1,q));

    up4 += newxi.cwiseProduct(fh1.replicate(1,q));

    up6 += newxi.cwiseProduct(f.replicate(1,q));

    xx = newxi.row(0).adjoint() * newxi.row(0);

    up7 += kroneckerProduct(f,xx);

    fh5 = kroneckerProduct(fh1,xx);
    up5 += fh5;
  }
  return List::create(FF,up1,up2,up3,up4,up5,up6,up7);
}


//[[Rcpp::export]]
List Efunprofile(Eigen::MatrixXd XX,   Eigen::VectorXd WW,  Eigen::VectorXd gam, Eigen::MatrixXd X,
              Eigen::VectorXd b,    Eigen::VectorXd h,    Eigen::MatrixXd Psi, Eigen::VectorXd d3,
              Eigen::MatrixXd IndL, Eigen::MatrixXd IndR, Eigen::MatrixXd V,   Eigen::MatrixXd B,
              double r, double pi){
  const int ipq(XX.rows()), n(d3.size()), q(XX.cols()), p(V.cols()), k(h.size());
  Eigen::MatrixXd newxi(n,q), lebzegx(n,k);
  Eigen::VectorXd inpsi(p), Vi(n), Wi(n), Emu(n), egx(n), ebzgx(n), egxmu(n), f(n), FF(n), fh1(n), fh2(n), up1(n), up2(n);
  Eigen::ArrayXd  logcfa(n), logl(n), sL(n), sR(n), diffS(n), logsd3(n), Emufrac(n), dGVi(n), dGWi(n);
  double C0;

  FF.fill(0); up1.fill(0); up2.fill(0);

  for(int i = 0; i < p; ++i){inpsi(i) = 1/Psi(i,i);}
  C0 = p*log(2*pi)+log(Psi.determinant());


  for (int ii = 0; ii < ipq; ++ii){
    newxi = XX.row(ii).replicate(n,1);

    egx    = (newxi * gam).array().exp();
    ebzgx  = (X * b + newxi * gam).array().exp();
    logcfa = (((V.array()-(newxi*B.adjoint()).array()).square()).matrix()*inpsi).array()+C0;

    lebzegx = ebzgx*h.transpose();
    Vi = (lebzegx.cwiseProduct(IndL)).rowwise().sum();
    Wi = (lebzegx.cwiseProduct(IndR)).rowwise().sum();
    sL = (-Gfun(Vi,r)).array().exp();
    sR = (-Gfun(Wi,r)).array().exp();


    diffS  = sL-sR;
    logsd3 = sL.log();

    dGVi = dGfun(Vi, r);
    dGWi = dGfun(Wi, r);
    for(int i = 0; i < n; ++i){
      if(diffS(i)  == 0){diffS(i) = 0.00001;}
      if(logsd3(i) == log(0.0)){logsd3(i) = -100000;}
      if(d3(i) != 1){
        logl(i) = log(diffS(i)) - 0.5*logcfa(i);
        Emu(i)  = (sL(i)*dGVi(i) - sR(i)*dGWi(i))/diffS(i);
      }
      else{
        logl(i) = logsd3(i) - 0.5*logcfa(i);
        Emu(i)  = dGVi(i);
      }
    }

    Emufrac = sL.cwiseProduct(dGVi);

    egxmu   = egx.cwiseProduct(Emu);

    f  = exp(logl+WW(ii));
    FF += f;

    fh1 = f.cwiseProduct(egxmu);
    up1 += fh1;

    fh2 = egx.array()/diffS*Emufrac*f.array();
    up2 += fh2;
  }
  return List::create(FF,up1,up2);
}



//[[Rcpp::export]]
Rcpp::List EfunCox(Eigen::MatrixXd XX,   Eigen::VectorXd WW,   Eigen::VectorXd gam,  Eigen::MatrixXd X,
                      Eigen::VectorXd b,    Eigen::VectorXd h,    Eigen::MatrixXd Psi,  Eigen::VectorXd d3,
                      Eigen::MatrixXd IndL, Eigen::MatrixXd IndR, Eigen::MatrixXd V,    Eigen::MatrixXd B,
                      double pi){
  const int ipq(WW.size()), n(d3.size()), q(XX.cols()),p(V.cols());
  Eigen::MatrixXd newxi(n,q), h3(n,q), h4(n,q), up3(n,q), up4(n,q);
  Eigen::MatrixXd up6(n,q), up5(n*q,q), up7(n*q,q), fh5(n*q,q), xx(q,q);
  Eigen::VectorXd Wnew(n),f(n),FF(n), h1(n), fh1(n), fh2(n), h2(n), up1(n), up2(n);
  FF.fill(0); up1.fill(0); up2.fill(0); up3.fill(0); up4.fill(0); up5.fill(0); up6.fill(0); up7.fill(0);

  double C0;
  Eigen::VectorXd inpsi(p), ebzgx(n), egx(n), logcfa(n), logl(n), bot(n);

  for(int i = 0; i < p; ++i){inpsi(i) = 1/Psi(i,i);}
  C0 = p*log(2*pi)+log(Psi.determinant());


  for (int ii = 0; ii < ipq; ++ii){
    newxi = XX.row(ii).replicate(n,1);

    egx = (newxi * gam).array().exp();
    ebzgx = (X * b + newxi * gam).array().exp();
    logcfa = (((V.array()-(newxi*B.adjoint()).array()).array().square()).matrix()*inpsi).array()+C0;


    for(int i = 0; i < n; ++i){
      if(d3(i)!=1){
        logl(i) = log( exp(-h.dot(IndL.row(i))*ebzgx(i))  -  exp(-h.dot(IndR.row(i))*ebzgx(i)) ) -0.5*logcfa(i);
      }
      else{
        logl(i) = log( exp(-h.dot(IndL.row(i))*ebzgx(i)) ) -0.5*logcfa(i);
      }
      bot(i) = 1-exp(-h.dot(IndR.row(i)-IndL.row(i))*ebzgx(i));
      if(bot(i) == 0.0){bot(i) = 1.0;}
      h2(i)  = egx(i)/bot(i);
      h3.row(i) = newxi.row(i)*egx(i)/bot(i);
      h4.row(i) = newxi.row(i)*egx(i);
    }

    f  = exp(logl.array()+WW(ii));
    FF += f;


    h1 = egx;
    fh1 = f.array()*h1.array();
    up1 += fh1;


    fh2 = f.array()*h2.array();
    up2 += fh2;


    up3 += h3.cwiseProduct(f.replicate(1,q));


    up4 += h4.cwiseProduct(f.replicate(1,q));

    up6 += newxi.cwiseProduct(f.replicate(1,q));

    xx = newxi.row(0).adjoint() * newxi.row(0);
    up7 += kroneckerProduct(f,xx);

    fh5 = kroneckerProduct(fh1,xx);
    up5 += fh5;
  }
  return List::create(FF,up1,up2,up3,up4,up5,up6,up7);
}

//[[Rcpp::export]]
List EfunCoxprofile(Eigen::MatrixXd XX,   Eigen::VectorXd WW,   Eigen::VectorXd gam,  Eigen::MatrixXd X,
                 Eigen::VectorXd b,    Eigen::VectorXd h,    Eigen::MatrixXd Psi,  Eigen::VectorXd d3,
                 Eigen::MatrixXd IndL, Eigen::MatrixXd IndR, Eigen::MatrixXd V,    Eigen::MatrixXd B,
                 double pi = 3.14159265){
  const int ipq(WW.size()), n(d3.size()), q(XX.cols()),p(V.cols());
  Eigen::MatrixXd newxi(n,q);
  Eigen::VectorXd f(n), FF(n), h1(n), fh1(n),fh2(n), h2(n), up1(n), up2(n);
  Eigen::VectorXd inpsi(p), ebzgx(n), egx(n), logcfa(n), logl(n), bot(n);
  double C0;

  FF.fill(0); up1.fill(0); up2.fill(0);

  for(int i = 0; i < p; ++i){inpsi(i) = 1/Psi(i,i);}
  C0 = p*log(2*pi)+log(Psi.determinant());


  for (int ii = 0; ii < ipq; ++ii){
    newxi = XX.row(ii).replicate(n,1);

    egx = (newxi * gam).array().exp();
    ebzgx = (X * b + newxi * gam).array().exp();
    logcfa = (((V.array()-(newxi*B.adjoint()).array()).array().square()).matrix()*inpsi).array()+C0;


    for(int i = 0; i < n; ++i){
      if(d3(i) != 1){
        logl(i) = log( exp(-h.dot(IndL.row(i))*ebzgx(i))  -  exp(-h.dot(IndR.row(i))*ebzgx(i)) ) -0.5*logcfa(i);
      }
      else{
        logl(i) = log( exp(-h.dot(IndL.row(i))*ebzgx(i)) ) -0.5*logcfa(i);
      }
      bot(i) = 1-exp(-h.dot(IndR.row(i)-IndL.row(i))*ebzgx(i));
      if(bot(i) == 0.0){bot(i) = 1.0;}
      h2(i)  = egx(i)/bot(i);
    }

    f  = exp(logl.array()+WW(ii));
    FF += f;


    h1 = egx;
    fh1 = f.array()*h1.array();
    up1 += fh1;


    fh2 = f.array()*h2.array();
    up2 += fh2;

  }
  return List::create(FF,up1,up2);
}

